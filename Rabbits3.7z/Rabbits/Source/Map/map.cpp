#include "Map.h"
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <string>
#include <vector>
#include <array>

Map::Map()
{
    int howManyRabbits, howManyHunters; //zmienne przechowuj�ce kolejno liczb� pocz�tkow� obiekt�w Rabbits oraz Hunters
    //Wczytanie danych przed u�ytkownika
    std::cout << "How many rabbits do you wish there to be at the start?" << std::endl;
    std::cin >> howManyRabbits;
    std::cout << "How many hunters do you wish there to be at the start?" << std::endl;
    std::cin >> howManyHunters;

    srand(time(NULL));

    clear();

    for (int i = 0; i < 3; i++) //dodanie do wektora 3 obiek�w Tree o losowych wsp�rz�dnych
    {
        trees.push_back(Tree(rand() % 10, rand() % 10));
    }

    for (int i = 0; i < 2; i++) //dodanie do wektora 2 obiekt�w Burrows
    {
        std::array<int, 2> coords = calculateCoords();
        burrows.push_back(Burrow(coords.at(0), coords.at(1)));
    }

    for (int i = 0; i < howManyHunters; i++) //dodanie do wektora obiekt�w Hunters o losowych wsp�rz�dnych
    {
        hunters.push_back(Hunter(rand() % 10, rand() % 10));
        hunters.at(i).collide(trees);
    }

    for (int i = 0; i < howManyRabbits; i++) //dodanie do wektora obiekt�w Rabbits o losowych wsp�rz�dnych
    {
        Rabbit* temp = new Rabbit(rand() % 10, rand() % 10, i);
        rabbits.push_back(temp);
        rabbits.at(i)->collide(trees);
    }
}

Map::~Map()
{
    //przypisanie obiektom Rabbits, Carrots, Traps, Branches wska�nika zerowego
    for (auto& r : rabbits)
    {
        if (r != nullptr)
        {
            delete r;
            r = nullptr;
        }
    }

    for (auto& c : carrots)
    {
        if (c != nullptr)
        {
            delete c;
            c = nullptr;
        }
    }

    for (auto& t : traps)
    {
        if (t != nullptr)
        {
            delete t;
            t = nullptr;
        }
    }

    for (auto& b : branches)
    {
        if (b != nullptr)
        {
            delete b;
            b = nullptr;
        }
    }
}

void Map::showMap(int phase) //wy�wietlanie warto�ci p�l mapy
{
    drawObjects();

    for (int i = 0; i < MAP_VERTICAL; i++)
    {
        for (int j = 0; j < MAP_HORIZONTAL; j++)
        {
            std::cout << board[i][j];
        }

        std::cout << "\n";
    }

    std::cout << "\nEPOKA: " << phase << "\n";
}

void Map::clear() //wy�wietlanie 'zarysu' oraz obramowa� mapy
{
    for (int i = 0; i < MAP_VERTICAL; i++)
    {
        for (int j = 0; j < MAP_HORIZONTAL; j++)
        {
            if (i % 4 == 0) board[i][j] = '-';
            else if (j % 7 == 0) board[i][j] = '|';
            else board[i][j] = ' ';
        }
    }
}

void Map::update(bool phaseChanged, int phase) //metoda odpowiedzialna za funkcjonowanie kr�lika
{
    std::vector<std::array<int, 2> > produceOffspring;

    for (auto& r : rabbits)
    {
        if (r != nullptr)
        {
            if (!r->getIsEatingCarrot())
            {
                for (auto& r2 : rabbits)
                {
                    if (r2 != nullptr && !r2->getIsEatingCarrot())
                    {
                        if (r->getPositionX() == r2->getPositionX()
                            && r->getPositionY() == r2->getPositionY()
                            && r->getIsMale() != r2->getIsMale()
                            && r->getAge() > 3 && r2->getAge() > 3)
                        {
                            r->setIsProcreating(true);
                            r2->setIsProcreating(true);
                        }
                    }
                }

                if (!r->getIsProcreating()) r->move();
                else
                {
                    r->procreate(&burrows);

                    if (!r->getIsMale() && r->getTimeInBurrow() > 1 && !r->getProducedOffspring())
                    {
                        r->setProducedOffspring(true);
                        produceOffspring.push_back({ r->getPositionX(), r->getPositionY() });
                    }
                }

                r->collide(trees);
            }

            r->update(phaseChanged);
            r->eatCarrot(carrots);
        }
    }

    std::vector<int> killedRabbits, destroyedTraps; //wektory przechowuj�cy kolejno zabite kr�liki oraz zniszczone pu�apki
    //dodanie do wektora nast�puje, po nast�pieniu przez kr�lika na pu�apk�

    for (int i = 0; i < rabbits.size(); i++)
    {
        for (int j = 0; j < traps.size(); j++)
        {
            if (rabbits.at(i) != nullptr && traps.at(j) != nullptr)
            {
                if (rabbits.at(i)->getPositionX() == traps.at(j)->getPositionX()
                    && rabbits.at(i)->getPositionY() == traps.at(j)->getPositionY())
                {
                    killedRabbits.push_back(i);
                    destroyedTraps.push_back(j);
                }
            }
        }
    }

    for (auto& kR : killedRabbits) //usuni�cie obiek�w tych Rabbits, kt�re s� ju� nie�ywe
    {
        delete rabbits.at(kR);
        rabbits.at(kR) = nullptr;
    }

    for (auto& dT : destroyedTraps) //usuni�cie tych obiekt�w Traps, kt�re zosta�y ju� aktywowane
    {
        delete traps.at(dT);
        traps.at(dT) = nullptr;
    }

    for (auto o : produceOffspring)
    {
        for (int i = 0; i < 3; i++)
        {
            Rabbit* temp = new Rabbit(o.at(0), o.at(1), rabbits.size() + 1);
            rabbits.push_back(temp);
        }
    }

    std::vector<int> brokenBranches; //wektor przechowuj�cy zniszone ga��zie

    for (auto& h : hunters)
    {
        h.update(phaseChanged);

        if (!h.getHasKilled())
        {
            h.move();
            h.collide(trees);
            for (auto& d : h.dogs)
            {
                d.move();
                d.collide(trees);
            }

            h.kill(&rabbits);
        }

        if (rand() % 10 == 0)
        {
            Trap* temp = new Trap(h.getPositionX(), h.getPositionY());
            traps.push_back(temp);
        }

        for (int i = 0; i < branches.size(); i++) //dodanie do wektora zniszczonyc ga��zi (tych, kt�re zosta�y nast�pione ju� przez my�liwego)
        {
            if (h.getPositionX() == branches.at(i)->getPositionX()
                && h.getPositionY() == branches.at(i)->getPositionY())
            {
                brokenBranches.push_back(i);
            }
        }
    }

    for (auto bB : brokenBranches)
    {
        if (branches.at(bB) != nullptr)
        {
            for (auto& r : rabbits) //sp�osznie kr�lik�w (ucieczka, gdy ga��� zostaje nast�piona)
            {
                if (r != nullptr)
                {
                    if (abs(r->getPositionX() - branches.at(bB)->getPositionX()) < 2
                        && abs(r->getPositionY() - branches.at(bB)->getPositionY()) < 2)
                    {
                        int newPosX = r->getPositionX() - branches.at(bB)->getPositionX();
                        int newPosY = r->getPositionY() - branches.at(bB)->getPositionY();

                        if (newPosX >= 0 && newPosX <= 9) r->setPositionX(newPosX);
                        if (newPosY >= 0 && newPosY <= 9) r->setPositionY(newPosY);
                    }
                }
            }

            delete branches.at(bB); //usuni�cie zniczszconych ga��zi
            branches.at(bB) = nullptr;
        }
    }

    if (phase % 3 == 0 && rand() % 3 == 0) //wygenerowanie marchwek na pustych polach od czasu up�yni�cia epoki trzeciej
    {
        std::array<int, 2> coords = calculateCoords();
        Carrot* temp = new Carrot(coords.at(0), coords.at(1));
        carrots.push_back(temp);
    }

    randomBranches();
}

void Map::drawObjects() //metoda odpowiedzialna za przydzielenie symboli obiekt�w na przypisanych do nich polach
{
    for (const auto& t : trees)
    {
        for (int i = 1; i < 4; i++)
        {
            for (int j = 1; j < 7; j++)
            {
                int x = t.getPositionX() * (FIELD_WIDTH + 1) + j;
                int y = t.getPositionY() * (FIELD_HEIGHT + 1) + i;

                board[y][x] = t.getSymbol(); //umieszczenie symboli obiekt�w w tablicy
            }
        }
    }

    //przypisanie symboli obiekt�w o wyznaczonych wsp�rz�dncyh jednego pola
    for (const auto& c : carrots) //przypisanie symbolu dla obiektu Carrot na polu
    {
        if (c != nullptr)
        {
            int x = c->getPositionX() * (FIELD_WIDTH + 1) + 2;
            int y = c->getPositionY() * (FIELD_HEIGHT + 1) + 1;

            board[y][x] = c->getSymbol();
        }
    }

    for (const auto& t : traps) //przypisanie symbolu dla obiektu Trap na polu
    {
        if (t != nullptr)
        {
            int x = t->getPositionX() * (FIELD_WIDTH + 1) + 5;
            int y = t->getPositionY() * (FIELD_HEIGHT + 1) + 1;

            board[y][x] = t->getSymbol();
        }
    }

    for (const auto& b : branches) //przypisanie symbolu dla obiektu Branch na polu
    {
        if (b != nullptr)
        {
            int x = b->getPositionX() * (FIELD_WIDTH + 1) + 1;
            int y = b->getPositionY() * (FIELD_HEIGHT + 1) + 3;

            board[y][x] = b->getSymbol();
        }
    }

    for (const auto& r : rabbits) //przypisanie symbolu dla obiektu Rabbit na polu
    {
        if (r != nullptr)
        {
            int x = r->getPositionX() * (FIELD_WIDTH + 1) + 3;
            int y = r->getPositionY() * (FIELD_HEIGHT + 1) + 2;

            if (r->getIsMale()) x++;

            board[y][x] = r->getSymbol();
        }
    }

    for (const auto& b : burrows) //przypisanie symbolu dla obiektu Burrow na polu
    {
        int x = b.getPositionX() * (FIELD_WIDTH + 1) + 1;
        int y = b.getPositionY() * (FIELD_HEIGHT + 1) + 1;

        board[y][x] = b.getSymbol();
    }

    for (const auto& h : hunters) //przypisanie symbolu dla obiektu Hunter na polu
    {
        int x = h.getPositionX() * (FIELD_WIDTH + 1) + 5;
        int y = h.getPositionY() * (FIELD_HEIGHT + 1) + 3;

        board[y][x] = h.getSymbol();

        for (const auto& d : h.dogs) //przypisanie symbolu dla obiektu Dog na polu
        {
            int x = d.getPositionX() * (FIELD_WIDTH + 1) + 5;
            int y = d.getPositionY() * (FIELD_HEIGHT + 1) + 2;
            board[y][x] = d.getSymbol();
        }
    }
}

std::array<int, 2> Map::calculateCoords() //metoda odpowiedzialna za zwr�cenie wsp�rz�dnych, na kt�rych nie znajduj� sie drzewa
{
    int x = rand() % 10;
    int y = rand() % 10;

    bool wasMoved = true;

    while (wasMoved)
    {
        wasMoved = false;
        for (auto t : trees)
        {
            if (x == t.getPositionX() && y == t.getPositionY())
            {
                if (x < 9) x++;
                else if (x > 0) x--;
                else if (y < 9) y++;
                else if (y > 0) y--;
                wasMoved = true;
            }
        }
    }

    return { x, y };
}

void Map::randomBranches() //metoda odpowiedzialna za wygenerowanie ga��zi w pobli�u drzew
{
    for (auto t : trees)
    {
        int x = t.getPositionX();
        int y = t.getPositionY();
        bool posWasSet = false;

        if (rand() % 2 && x < 9)
        {
            x++;
            posWasSet = true;
        }
        else if (x > 0)
        {
            x--;
            posWasSet = true;
        }

        if (rand() % 2 && y < 9)
        {
            y++;
            posWasSet = true;
        }
        else if (y > 0)
        {
            y--;
            posWasSet = true;
        }

        if (rand() % 20 == 0 && posWasSet)
        {
            Branch* temp = new Branch(x, y);
            branches.push_back(temp);
        }
    }
}

