#ifndef MAP_H
#define MAP_H

#include <vector>
#include <array>

#include "../MapObject/MapObject.h"
#include "../MapObject/MovingObject/MovingObject.h"
#include "../MapObject/MovingObject/Rabbit/Rabbit.h"
#include "../MapObject/MovingObject/Hunter/Hunter.h"
#include "../MapObject/Burrow/Burrow.h"
#include "../MapObject/Tree/Tree.h"
#include "../MapObject/Carrot/Carrot.h"
#include "../MapObject/Trap/Trap.h"
#include "../MapObject/Branch/Branch.h"

#define FIELD_WIDTH 6 //szerko�� jednego pola na mapie
#define FIELD_HEIGHT 3 //wysoko�� jednego pola na mapie

#define MAP_VERTICAL 10 * FIELD_HEIGHT + 11 //wysoko�� ca�o�ciowa mapy
#define MAP_HORIZONTAL 10 * FIELD_WIDTH + 11 //szeroko�� ca�o�ciowa mapy
//klasa map, odpowiedz
class Map
{
public:
    Map();
    ~Map();
    void showMap(int phase);
    void clear();
    void update(bool phaseChanged, int phase);

private:
    std::array<int, 2> calculateCoords();
    void randomBranches();

    std::vector<Rabbit*> rabbits;
    std::vector<Hunter> hunters;
    std::vector<Burrow> burrows;
    std::vector<Tree> trees;
    std::vector<Carrot*> carrots;
    std::vector<Trap*> traps;
    std::vector<Branch*> branches;

    char board[MAP_VERTICAL][MAP_HORIZONTAL]; //tablica odpowiedzialna za ca�� map�
    void drawObjects();

};


#endif // MAP_H
