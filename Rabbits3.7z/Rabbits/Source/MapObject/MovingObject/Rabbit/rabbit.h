#ifndef RABBIT_H
#define RABBIT_H

#include <vector>

#include "../MovingObject.h"
#include "../../Burrow/Burrow.h"
#include "../../Carrot/Carrot.h"

//klasa odpowiedzialna za "dzia�anie" kr�lika, jego dane i r�ne czynno�ci;
//na razie niekompletna

class Rabbit : public MovingObject
{
public:
    Rabbit() = default;
    Rabbit(int pos_x, int pos_y, int num);
    void update(bool phaseChanged);
    void procreate(std::vector<Burrow>* p_burrows);
    void eatCarrot(std::vector<Carrot*>& carrots);
    //virtual ~Rabbit();

    bool getIsProcreating() const;
    bool getIsMale() const;
    int getTimeInBurrow() const;
    int getAge() const;
    bool getProducedOffspring() const;
    bool getIsEatingCarrot() const;

    void setIsProcreating(bool value);
    void setTimeInBurrow(int value);
    void setProducedOffspring(bool value);
    //void setIsEatingCarrot(bool value);

private:
    void findClosestBurrow(std::vector<Burrow>* p_burrows);

    Burrow* closestBurrow = nullptr;
    int number;
    int age = 0;
    int timeInBurrow = 0;
    int timeEatingCarrot = 0;
    int carrotEaten = -1;
    bool isMale;
    bool isProcreating = false;
    bool producedOffspring = false;
    bool isEatingCarrot = false;
};

#endif // RABBIT_H
