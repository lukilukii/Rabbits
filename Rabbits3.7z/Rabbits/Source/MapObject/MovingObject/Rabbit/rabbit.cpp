#include "Rabbit.h"

#include <cstdlib>
#include <ctime>
#include <limits>
#include <iostream>

Rabbit::Rabbit(int pos_x, int pos_y, int num)
    : MovingObject(pos_x, pos_y), number(num)
{
    isMale = rand() % 2;
    
    if (isMale) symbol = 'R';
    else symbol = 'r';
}

void Rabbit::update(bool phaseChanged)
{
    if (phaseChanged)
    {
        age++;
        if (isProcreating
            && closestBurrow->getPositionX() == pos_x
            && closestBurrow->getPositionY() == pos_y) timeInBurrow++;
        if (isEatingCarrot) timeEatingCarrot++;
    }
}

void Rabbit::procreate(std::vector<Burrow>* p_burrows)
{
    if (closestBurrow == nullptr) findClosestBurrow(p_burrows);
    else if (timeInBurrow == 0)
    {
        int dirX = closestBurrow->getPositionX() - pos_x;
        int dirY = closestBurrow->getPositionY() - pos_y;

        if (dirX != 0) pos_x += dirX / abs(dirX);
        if (dirY != 0) pos_y += dirY / abs(dirY);
    }
    else
    {
        if ((isMale && timeInBurrow > 1) || (!isMale && timeInBurrow > 2))
        {
            isProcreating = false;
            timeInBurrow = 0;
            producedOffspring = false;
            closestBurrow = nullptr;

            if (isMale)
            {
                if (pos_x < 9) pos_x++;
                else if (pos_x > 0) pos_x--;
                else if (pos_y < 9) pos_y++;
                else if (pos_y > 0) pos_y--;
            }
            else
            {
                if (pos_y < 9) pos_y++;
                else if (pos_y > 0) pos_y--;
                else if (pos_x < 9) pos_x++;
                else if (pos_x > 0) pos_x--;
            }
        }
    }
}

void Rabbit::eatCarrot(std::vector<Carrot*>& carrots)
{
    if (!isEatingCarrot)
    {
        for (int i = 0; i < carrots.size(); i++)
        {
            if (carrots.at(i) != nullptr)
            {
                if (carrots.at(i)->getPositionX() == pos_x && carrots.at(i)->getPositionY() == pos_y)
                {
                    isEatingCarrot = true;
                    carrotEaten = i;
                }
            }
        }
    }

    if (timeEatingCarrot > 2)
    {
        isEatingCarrot = false;
        delete carrots.at(carrotEaten);
        carrots.at(carrotEaten) = nullptr;
    }
}

void Rabbit::findClosestBurrow(std::vector<Burrow>* p_burrows)
{
    int shortestDistance = std::numeric_limits<int>::max();

    for (auto& b : *p_burrows)
    {
        int dist = abs(pos_x - b.getPositionX()) + abs(pos_y - b.getPositionY());
        if (dist < shortestDistance)
        {
            shortestDistance = dist;
            closestBurrow = &b;
        }
    }
}

/*
Rabbit::~Rabbit()
{
    //dtor
}
*/

bool Rabbit::getIsProcreating() const
{
    return isProcreating;
}

bool Rabbit::getIsMale() const
{
    return isMale;
}

int Rabbit::getTimeInBurrow() const
{
    return timeInBurrow;
}

int Rabbit::getAge() const
{
    return age;
}

bool Rabbit::getProducedOffspring() const
{
    return producedOffspring;
}

bool Rabbit::getIsEatingCarrot() const
{
    return isEatingCarrot;
}

void Rabbit::setTimeInBurrow(int value)
{
    timeInBurrow = value;
}

void Rabbit::setIsProcreating(bool value)
{
    isProcreating = value;
}

void Rabbit::setProducedOffspring(bool value)
{
    producedOffspring = value;
}

//void Rabbit::setIsEatingCarrot(bool value)
//{
//    isEatingCarrot = value;
//}