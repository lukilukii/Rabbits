#ifndef TRAP_H
#define TRAP_H

#include "../MapObject.h"

//klasa odpowiedzialna za pułapke

class Trap : public MapObject
{
public:
    Trap() = default;
    Trap(int pos_x, int pos_y);
};

#endif // TRAP_H
