#include "Trap.h"

Trap::Trap(int pos_x, int pos_y)
    : MapObject(pos_x, pos_y)
{
    symbol = 't'; //symbol jaki ma si� wy�wietlic na mapie, je�eli na danym polu znajduje si� pu�apka
}

