#include "Branch.h"

Branch::Branch(int pos_x, int pos_y)
    : MapObject(pos_x, pos_y)
{
    symbol = '/'; //symbol jaki ma si� wy�wietlic na mapie, je�eli na danym polu znajduje si� ga��z
}
