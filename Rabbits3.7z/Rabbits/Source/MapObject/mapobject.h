#ifndef MAPOBJECT_H
#define MAPOBJECT_H
// klasa odpowiedzialna za obiekty znajduj�ce si� na mapie
#include <vector>

class MapObject
{
public:
    MapObject() = default;
    MapObject(int pos_x, int pos_y);

    int getPositionX() const;
    int getPositionY() const;

    void setPositionX(int newPos);
    void setPositionY(int newPos);

    char getSymbol() const;

protected:
    char symbol;
    int pos_x;
    int pos_y;
};

#endif // MAPOBJECT_H
