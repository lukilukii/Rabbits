#ifndef TREE_H
#define TREE_H

#include "../MapObject.h"

//klasa drzewo

class Tree : public MapObject
{
public:
    Tree() = default;
    Tree(int pos_x, int pos_y);
};

#endif // TREE_H
