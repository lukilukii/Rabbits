#ifndef BURROW_H
#define BURROW_H

#include "../../MapObject/MapObject.h"

//klasa odpowiedzialna za nore


class Burrow : public MapObject
{
public:
    Burrow() = default;
    Burrow(int pos_x, int pos_y);
};

#endif // BURROW_H
