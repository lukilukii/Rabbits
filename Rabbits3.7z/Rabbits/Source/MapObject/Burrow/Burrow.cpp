#include "Burrow.h"

Burrow::Burrow(int pos_x, int pos_y)
	: MapObject(pos_x, pos_y)
{
	symbol = 'b'; //symbol jaki ma si� wy�wietlic na mapie, je�eli na danym polu znajduje si� nora
}

