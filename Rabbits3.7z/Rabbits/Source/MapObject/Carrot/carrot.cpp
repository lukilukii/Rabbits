#include "Carrot.h"

Carrot::Carrot(int pos_x, int pos_y)
    : MapObject(pos_x, pos_y)
{
    symbol = 'c'; //symbol jaki ma si� wy�wietlic na mapie, je�eli na danym polu znajduje si� marchewka
}

