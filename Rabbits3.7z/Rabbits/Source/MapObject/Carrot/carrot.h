#ifndef CARROT_H
#define CARROT_H

#include "../MapObject.h"

//klasa odpowiedzialna za marchweke

class Carrot : public MapObject
{
public:
    Carrot() = default;
    Carrot(int pos_x, int pos_y);
};

#endif // CARROT_H
