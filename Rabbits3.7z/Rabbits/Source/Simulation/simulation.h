#ifndef SIMULATION_H
#define SIMULATION_H

#include "../Map/Map.h"

class Simulation
{
    public:
        Simulation();
        void run();
        //void menu();

    private:
        int howManyPhases = 100;
        int phase = 0, phaseCounter = 0;
        bool quit = false;
        bool phaseChanged = false;

        Map mapa;
};

#endif // SIMULATION_H
