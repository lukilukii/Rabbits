#include "Simulation.h"

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <thread>
#include <chrono>

Simulation::Simulation()
{
    std::cout << "How many phases of the simulation do you wish to go through? " << std::endl; //czesc menu, wczytanie przez uzytkownika czasu trwania symulacji w postaci liczby epok
    std::cin >> howManyPhases;
}

void Simulation::run()
{
    while (!quit)
    {
        mapa.clear();
        mapa.update(phaseChanged, phase);
        std::cout << std::string(MAP_VERTICAL, '\n');
        mapa.showMap(phase);
        std::this_thread::sleep_for(std::chrono::milliseconds(1000)); //czas po kt�rym nast�puje 'aktualizacja' - od�wie�enie sie mapy
        phaseCounter++;
        if (phaseCounter == 2) //zwiekszenie epoki o 1, je�eli zeosta�y wykonane 2 ruchy na mapie
        {
            phase++;
            phaseCounter = 0;
            phaseChanged = true;
        }
        else
        {
            phaseChanged = false;
        }

        if (phase > howManyPhases) quit = true; //zakonczenie symulacji, jezeli nastapila epoka, podana przez uzytkownika
    }
    getchar();
}
