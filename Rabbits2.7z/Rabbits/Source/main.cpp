#include <iostream>
#include "Simulation/Simulation.h"

int main()
{
    //rozpoczecie wlasciwej symulacji
    Simulation *symulacja = new Simulation();
    symulacja->run();
    delete symulacja;

    return 0;
}
