#include "Tree.h"

Tree::Tree(int pos_x, int pos_y)
	: MapObject(pos_x, pos_y)
{
	symbol = 'T';
}
