#include "MapObject.h"

#include <cstdlib>

MapObject::MapObject(int pos_x, int pos_y)
{
    this->pos_x = pos_x;
    this->pos_y = pos_y;
}

int MapObject::getPositionX() const
{
    return pos_x;
}

int MapObject::getPositionY() const
{
    return pos_y;
}

void MapObject::setPositionX(int newPos)
{
    pos_x = newPos;
}

void MapObject::setPositionY(int newPos)
{
    pos_y = newPos;
}

char MapObject::getSymbol() const
{
    return symbol;
}
