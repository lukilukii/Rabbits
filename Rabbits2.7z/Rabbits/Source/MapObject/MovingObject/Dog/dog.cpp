#include "Dog.h"

#include <cstdlib>

Dog::Dog(int pos_x, int pos_y)
    : MovingObject(pos_x, pos_y)
{
    symbol = 'd'; //symbol jaki ma się wyświetlic na mapie, jeżeli na danym polu znajduje się pies
}


void Dog::update(int nopos_x, int nopos_y)
{
    opos_x = nopos_x;
    opos_y = nopos_y;
}

void Dog::move() //metoda odpowiedzialana za poruszanie sie psa
{
    if (rand() % 2) pos_x++;
    else if (rand() % 2) pos_x--;
    if (rand() % 2) pos_y++;
    else if (rand() % 2) pos_y--;

    if (pos_x > opos_x + 1) pos_x = opos_x + 1;
    if (pos_y > opos_y + 1) pos_y = opos_y + 1;
    if (pos_x < opos_x - 1) pos_x = opos_x - 1;
    if (pos_y < opos_y - 1) pos_y = opos_y - 1;

    if (pos_x > 9) pos_x = 9;
    if (pos_y > 9) pos_y = 9;
    if (pos_x < 0) pos_x = 0;
    if (pos_y < 0) pos_y = 0;
}


