#ifndef DOG_H
#define DOG_H

#include "../MovingObject.h"

//klasa odpowiedzialna za psa

class Dog : public MovingObject
{
public:
    Dog() = default;
    Dog(int pos_x, int pos_y);

    void update(int nopos_x, int nopos_y);
    void move();

private:

    int opos_x;
    int opos_y;

};

#endif // DOG_H
