#ifndef MOVINGOBJECT_H
#define MOVINGOBJECT_H

#include "../MapObject.h"

#include <vector>
#include "../Tree/Tree.h"
//klasa Moving Object odpowiedzialna za obiekty poruszaj�ce sie
class MovingObject : public MapObject
{
public:
	MovingObject() = default;
	MovingObject(int pos_x, int pos_y);
	virtual void move();
	void collide(const std::vector<Tree>& trees);
};

#endif // MOVINGOBJECT_H
