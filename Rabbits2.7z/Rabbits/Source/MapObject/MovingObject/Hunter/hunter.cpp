#include "Hunter.h"

#include <cstdlib>

Hunter::Hunter(int pos_x, int pos_y)
    : MovingObject(pos_x, pos_y)
{
    symbol = 'h'; //symbol jaki ma si� wy�wietlic na mapie, je�eli na danym polu znajduje si� my�liwy
}

    for (int i = 0; i < rand() % 3; i++) //dodanie do wektora losowej liczby ps�w od 0 do 2
    {
        dogs.push_back(Dog(pos_x, pos_y));
    }
}

void Hunter::kill(std::vector<Rabbit*>* rabbits) //metoda odpowiedzialna za zabicie wykrycie kr�lika oraz zabicie, je�eli znajduje si� w zasi�gu
{
    std::vector<int> aims; //wektor przechowuj�cy kr�liki, znajduj�ce sie w pobli�u my�liwego

    for (int i = 0; i < rabbits->size(); i++)
    {
        if (rabbits->at(i) != nullptr)
        {
            for (int j = pos_x - 1; j <= pos_x + 1; j++)
            {
                for (int k = pos_y - 1; k <= pos_y + 1; k++)
                {
                    if (j == rabbits->at(i)->getPositionX()
                        && k == rabbits->at(i)->getPositionY())
                    {
                        aims.push_back(i);
                    }
                }
            }
        }
    }

    if (!aims.empty()) //wylosowanie jednego z kr�lik�w, kt�ry znajduje si� w pobli�u i ma zosta� zabity przez my�liwego
    {
        int pos = aims.at(rand() % aims.size());

        if (rabbits->at(pos)->getTimeInBurrow() == 0)
        {
            delete rabbits->at(pos);
            rabbits->at(pos) = nullptr;
            hasKilled = true;
        }
    }

    for (auto& d : dogs)
    {
        for (auto& r : *rabbits)
        {
            if (r != nullptr
                && d.getPositionX() == r->getPositionX()
                && d.getPositionY() == r->getPositionY()
                && r->getTimeInBurrow() == 0)
            {
                delete r;
                r = nullptr;
            }
        }
    }
}

void Hunter::update(bool phaseChanged)
{
    if (phaseChanged) hasKilled = false;

    for (auto& d : dogs)
    {
        d.update(pos_x, pos_y);
    }
}

bool Hunter::getHasKilled() const
{
    return hasKilled;
}
