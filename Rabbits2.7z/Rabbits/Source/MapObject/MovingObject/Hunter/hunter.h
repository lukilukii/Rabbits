#ifndef HUNTER_H
#define HUNTER_H

#include "../MovingObject.h"
#include "../Rabbit/Rabbit.h"
#include "../Dog/Dog.h"
#include <vector>

//klasa odpowiedzialna za myśliwego

class Hunter : public MovingObject
{
public:
    Hunter() = default;
    Hunter(int pos_x, int pos_y);

    void update(bool phaseChanged);
    void kill(std::vector<Rabbit*>* rabbits);

    bool getHasKilled() const;
    std::vector<Dog> dogs;

private:
    bool hasKilled = false;
};

#endif // HUNTER_H
