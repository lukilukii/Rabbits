#include "MovingObject.h"

#include <cstdlib>
#include "../Tree/Tree.h"


MovingObject::MovingObject(int pos_x, int pos_y)
    : MapObject(pos_x, pos_y)
{
}

void MovingObject::move() //metoda odpowiedzialna za poruszanie si� sie losowe obiekt�w
{
    if (rand() % 2) pos_x++;
    else if (rand() % 2) pos_x--;
    if (rand() % 2) pos_y++;
    else if (rand() % 2) pos_y--;

    if (pos_x > 9) pos_x = 9;
    if (pos_y > 9) pos_y = 9;
    if (pos_x < 0) pos_x = 0;
    if (pos_y < 0) pos_y = 0;
}

void MovingObject::collide(const std::vector<Tree>& trees) //metoda odpowiedzialna za sprawdzenie, czy dany obiektnie koliduje z obiektem Tree
{
    bool wasMoved = true;

    while (wasMoved)
    {
        wasMoved = false;
        for (auto t : trees)
        {
            if (pos_x == t.getPositionX() && pos_y == t.getPositionY())
            {
                if (pos_x < 9) pos_x++;
                else if (pos_x > 0) pos_x--;
                else if (pos_y < 9) pos_y++;
                else if (pos_y > 0) pos_y--;
                wasMoved = true;
            }
        }
    }
}
