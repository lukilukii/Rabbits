#ifndef BRANCH_H
#define BRANCH_H

#include "../../MapObject/MapObject.h"

//klasa odpowiedzialna za gałąz

class Branch : public MapObject
{
public:
    Branch() = default;
    Branch(int pos_x, int pos_y);
};

#endif // BRANCH_H
